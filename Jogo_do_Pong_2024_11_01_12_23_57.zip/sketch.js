//variáveis da bolinha
let xBolinha = 100; // criando a variável "xBolinha", tendo o valor 100
let yBolinha = 200; // criando a variável "yBolinha", tendo o valor 200
let diametro = 20; // criando a variável "diametro", tendo o valor 20 
let raio = diametro / 2; // criando variável "raio", tendo metade do valor da variável "diametro"

//variáveis do oponente
let xRaqueteOponente = 585; // criando variável "xRaqueteOponente", tendo o valor 585
let yRaqueteOponente = 150; // criando variável "yRaqueteOponente", tendo o valor 150

//velocidade da bolinha
let velocidadeXBolinha = 6; // definindo velocidade do eixo x, igual a 6 
let velocidadeYBolinha = 6; // definindo velocidade do eixo y, igual a 6 

//variáveis da raquete
let xRaquete = 5; // criando variável "xRaquete", tendo o valor 5
let yRaquete = 150; // criando variável "yRaquete", tendo o valor 150 
let raqueteComprimento = 10; // criando variável "raqueteComprimento", tendo o valor 10
let raqueteAltura = 90; // criando variável "raqueteAltura", tendo o valor 90 

//placar do jogo
let meusPontos = 0; // criando variável "meusPontos", tendo o valor 0 
let pontosDoOponente = 0; // criando variável "pontosDoOponente", tendo o valor 0


//sons do jogo
let raquetada; // criando variável de som "raquetada"
let ponto; // criando variável de som "ponto"
let trilha; // criando variável de som "trilha"

let colidiu = false; // criando variável "colidiu", tendo valor falso 

function setup() { // função "setup"
  createCanvas(600, 400); // definindo tamanho do cenário
    trilha.loop(); // tocar "trilha.mp3"
}

function draw() { // função do desenho 
    background(0); // cor do cenário 
    mostraBolinha(); // adicionando a bolinha no jogo 
    movimentaBolinha(); // movimentando a bolinha 
    verificaColisaoBorda(); // verificando quando a bolinha colidir com a borda para continuar se movimentando 
    mostraRaquete(xRaquete, yRaquete); // adicionando a raquete no jogo com seus parametros 
    movimentaMinhaRaquete(); // movimentando a raquete
    verificaColisaoRaquete(xRaquete, yRaquete); // verificando a colisão da minha raquete com a bolinha 
    verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente); // verificando a colisão da raquete do oponente com a bolinha 
    mostraRaquete(xRaqueteOponente, yRaqueteOponente); // adicionando a raquete do oponente com seus parametros
    movimentaRaqueteOponente(); // movimentando a raquete do oponente
    incluiPlacar(); // adicionando o placar do jogo 
    marcaPonto(); // marcando os pontos do jogo
}
function mostraBolinha() { // função da bolinha no jogo
  circle(xBolinha, yBolinha, diametro); // tamanho da bolinha
}

function movimentaBolinha() { // função do movimento da bolinha
  xBolinha += velocidadeXBolinha; // fazendo a bolinha se movimentar nas laterias 
  yBolinha += velocidadeYBolinha; // fazendo a bolinha se movimentar para cima e para baixo
}

function verificaColisaoBorda() { // função para verficar a colisão da bolinha em alguma borda
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadeXBolinha *= -1; // se a bolinha tocar nas bordas laterais, vai colidir e continuar se movimentando
  }
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeYBolinha *= -1; // se a bolinha tocar na borda de cima ou na de baixo, vai colidir e continuar se movimentando 
  }
}

function mostraRaquete(x,y) { // função da raquete no jogo
    rect(x, y, raqueteComprimento, raqueteAltura); // tamanho da raquete
}

function movimentaMinhaRaquete() { // função do movimento da raquete
  if(keyIsDown(UP_ARROW)) {
    yRaquete -= 10; // se a "seta para cima" for pressionada a raquete se move para cima em linha reta 
  }
  if(keyIsDown(DOWN_ARROW)) {
    yRaquete += 10; // se a "seta para baixo" for pressionada a raquete se move para baixo em linha reta 
  }
}

function verificaColisaoRaquete() { // função para verificar se a bolinha tocar na raquete 
  if (xBolinha - raio < xRaquete + raqueteComprimento && yBolinha - raio < yRaquete + raqueteAltura && yBolinha + raio > yRaquete) {
    velocidadeXBolinha *= -1; // se a bolinha tocar na raquete vai rebater e continuar se movimentando, porém se a raquete estiver para cjma ou para baixo a bolinha irá colidir normalmente nas bordas  
     raquetada.play(); // tocar som "raquetada"
  }
}

function verificaColisaoRaquete(x, y) { // função para verificar se a bolinha tocar na raquete 
    colidiu = collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, raio); // definindo variável "colidiu" = colisão da bolinha com a raquete de acordo com seus parametros
    if (colidiu){
        velocidadeXBolinha *= -1;
        raquetada.play(); // se a bolinha colidir irá tocar o som "raquetada"
  }
}

function movimentaRaqueteOponente() { // função do movimento da raquete do oponente 
    if (keyIsDown(87)){
        yRaqueteOponente -= 10; // se a "seta para cima" for pressionada, a raquete irá para cima 
    }
    if (keyIsDown(83)){
        yRaqueteOponente += 10; // se a "seta para baixo" for pressionada, a raquete irá para baixo 
    }}


function incluiPlacar(){ // função para adicionar o placar no jogo
  stroke(255) // batida (225)
    textAlign(CENTER); // alinhamento do texto 
    textSize(16); // tamanho do texto 
    fill(color(255,140, 0)); // preenchendo o meu placar com cor
    rect(150, 10, 40, 20); // tamanho do retangulo 
    fill(255); // preencher (255)
    text(meusPontos, 170, 26); // nome do placar: meusPontos
    fill(color(255,140, 0)); // preenchendo placar oponente com cor
    rect(450, 10, 40, 20); // tamanho do retangulo 
    fill(255); // preencher (255)
    text(pontosDoOponente, 470, 26); // nome do placar: pontosDoOponente 



}


function marcaPonto() { // função para marcar os pontos
    if (xBolinha > 590) {
        meusPontos += 1;
        ponto.play();
    }
    if (xBolinha < 10) {
        pontosDoOponente += 1;
        ponto.play();
    }
}


function preload(){ // função para carregar sons 
  trilha = loadSound("trilha.mp3"); // quando tiver alguma trilha, carregar som "trilha.mp3"
  ponto = loadSound("ponto.mp3"); // quando tiver algum ponto, carregar som "ponto.mp3"
  raquetada = loadSound("raquetada.mp3"); // quando tiver alguma raquetada, carregar som "raquetada.mp3"
}

